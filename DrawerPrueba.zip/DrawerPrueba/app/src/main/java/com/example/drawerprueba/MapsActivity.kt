package com.example.drawerprueba

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.example.drawerprueba.databinding.ActivityMapsBinding
import com.google.android.gms.maps.model.*

class MapsActivity : AppCompatActivity(), OnMapReadyCallback , GoogleMap.OnMapClickListener, GoogleMap.OnMapLongClickListener {

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        mMap.mapType = GoogleMap.MAP_TYPE_SATELLITE
        mMap.mapType = GoogleMap.MAP_TYPE_HYBRID
        mMap.mapType = GoogleMap.MAP_TYPE_NONE
        mMap.mapType = GoogleMap.MAP_TYPE_NORMAL
        mMap.mapType = GoogleMap.MAP_TYPE_TERRAIN
        // Add a marker in Sydney and move the camera
        val cadiz = LatLng(36.529147, -6.294104)
        mMap.addMarker(MarkerOptions()
            .position(cadiz)
            .title("CES Juan Pablo II")
            .draggable(true)
            .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN))
            .icon(BitmapDescriptorFactory.fromResource(R.drawable.gallina))
            .alpha(0.6f)
            .snippet("Precio oferta: 50€"))





        mMap.animateCamera(CameraUpdateFactory.newLatLng(cadiz))
        googleMap.moveCamera((CameraUpdateFactory.zoomTo(20f)))

        //GoogleMap.setBuildingsEnabled(false).
        googleMap.setTrafficEnabled(true);

        val cadizCentral = LatLngBounds(
            LatLng(36.52869442118975, -6.2939915369034205), // SW bounds
            LatLng(36.529625725486234, -6.292448262691893) // NE bounds
        )
        mMap.moveCamera(CameraUpdateFactory.newLatLngBounds(cadizCentral, 10))
        mMap.setLatLngBoundsForCameraTarget(cadizCentral)
        mMap.animateCamera(CameraUpdateFactory.zoomTo(20f), 5000, null)


        val cameraPosition = CameraPosition.Builder()

            .target(cadiz)
            .zoom(20f) // Sets the zoom
            .bearing(-90f) // Sets the orientation
            .tilt(70f) // Sets the tilt of the camera to 70 degrees
            .build()

        mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition))
        mMap.uiSettings.isCompassEnabled = true
        mMap.uiSettings.isZoomControlsEnabled = true
    }
    override fun onMapClick(point: LatLng?) {
        Toast.makeText(this,"Oferta en, point=$point", Toast.LENGTH_SHORT).show()
    }

    override fun onMapLongClick(point: LatLng?) {
        Toast.makeText(this,"Demanda en, point=$point", Toast.LENGTH_LONG).show()
    }



}